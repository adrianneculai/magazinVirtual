I'm always more than happy to fix a bug that you found or help you to build something cool with Siema, but...

- - -

Before asking about XYZ, please make sure that the solution ready to copy & paste is not provided on a Siema's CodePen collection: http://codepen.io/collection/Adpkkd/

- - -

If you found a bug — CodePen / JS Bin / JSFiddle example is irreplaceable. Please, please, please...

- - -
